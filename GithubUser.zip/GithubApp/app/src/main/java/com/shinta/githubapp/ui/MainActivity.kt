package com.shinta.githubapp.ui


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.shinta.githubapp.R
import com.shinta.githubapp.adapter.UserAdapter
import com.shinta.githubapp.data.response.Users
import com.shinta.githubapp.databinding.ActivityMainBinding
import com.shinta.githubapp.modelview.MainViewModel


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.hide()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val layoutManager = LinearLayoutManager(this)
        binding.rvUser.layoutManager = layoutManager

        val mainViewModel = ViewModelProvider(
            this, ViewModelProvider.NewInstanceFactory()
        ).get(MainViewModel::class.java)

        mainViewModel.users.observe(this) { users ->
            setUserData(users.items)
        }

        mainViewModel.listUser.observe(this) { userData ->
            setUserData(userData)
        }

        mainViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { textView, actionId, event ->
                    val searchText = searchView.text.toString()
                    if (searchText.isNotEmpty()) {
                        searchBar.setText(searchText)
                        searchView.hide()
                        mainViewModel.findUsersBySearch(searchText)
                        false
                    } else {
                        Toast.makeText(
                            this@MainActivity,
                            "Please enter a search query",
                            Toast.LENGTH_SHORT
                        ).show()
                        true
                    }
                }
        }

        mainViewModel.users.observe(this) { users ->
            if (users != null && users.isNotEmpty()) {
                setUserData(users.items)
                showLoading(false)
            } else {
                showToast("No relevant data found")
            }
        }
    }

    private fun setUserData(Users: List<Users?>?) {
        val adapter = UserAdapter()
        adapter.submitList(Users)
        binding.rvUser.adapter = adapter
    }

    private fun showLoading(state: Boolean) {
        binding.progressBar.visibility = if(state) View.VISIBLE else View.GONE
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

}



