package com.shinta.githubapp.ui

import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.shinta.githubapp.R
import com.shinta.githubapp.adapter.SectionsPagerAdapter
import com.shinta.githubapp.data.response.DetailUserResponse
import com.shinta.githubapp.databinding.ActivityDetailUserBinding
import com.shinta.githubapp.modelview.DetailUserViewModel

class DetailUser : AppCompatActivity() {
    companion object {
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
    }

    private lateinit var binding: ActivityDetailUserBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_user)

        supportActionBar?.hide()

        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val detailUserViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            DetailUserViewModel::class.java
        )

        detailUserViewModel.username= intent.extras?.getString("username").toString()
        detailUserViewModel.detailUser.observe(this){userDetail ->
            setDataDetailUser(userDetail)
        }
        detailUserViewModel.isLoading.observe(this){
            showLoading(it)
        }

        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        supportActionBar?.elevation = 0f



    }


    private fun setDataDetailUser(detailUser: DetailUserResponse){

        binding.tvUsernameDetail.text = detailUser.login
        binding.tvUsernameAlias.text = detailUser.name
        binding.tvFollowing.text = "${detailUser.following} Following"
        binding.tvFollowers.text = "${detailUser.followers} Followers"

        Glide.with(this).load(detailUser.avatarUrl).into(binding.avatarDetail)
    }

    private fun showLoading(state: Boolean) {
        binding.progressBar.visibility = if (state) View.VISIBLE else View.GONE
    }
}